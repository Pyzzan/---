export interface TPAMachine {
  id: number;
  name: string;
  projectName: string;
  cycleTime: number;
  lastSignalTime: number | null;
  isRunning: boolean;
  hasError: boolean;
  itemsPerCycle: number;
  totalProduced: number;
  currentCycleCount: number;
  assignedSpecialists: SpecialistType[];
  specialistsCalledAt: number | null;
}

export type SpecialistType = 'electrician' | 'mechanic' | 'technologist' | 'operator' | 'maintenance';

export interface SpecialistInfo {
  type: SpecialistType;
  label: string;
  icon: string;
  color: string;
}

export interface SpecialistContact {
  telegramChatId: string;
  phone: string;
  enabled: boolean;
}

export interface NotificationSettings {
  telegramBotToken: string;
  telegramEnabled: boolean;
  webNotificationsEnabled: boolean;
  soundEnabled: boolean;
  contacts: Record<SpecialistType, SpecialistContact>;
}

export interface AppSettings {
  title: string;
  subtitle: string;
  theme: 'dark' | 'blue' | 'green' | 'industrial';
  adminPassword: string;
  notifications: NotificationSettings;
}

export interface NotificationLog {
  id: number;
  timestamp: number;
  machineName: string;
  specialist: SpecialistType;
  method: string;
  status: 'sent' | 'failed' | 'pending';
  message: string;
}
