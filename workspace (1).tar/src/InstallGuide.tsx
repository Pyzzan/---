import { useState } from 'react';

interface InstallGuideProps {
  onClose: () => void;
}

type Section = 'local' | 'server' | 'remote' | 'docker' | 'telegram' | 'security';

export default function InstallGuide({ onClose }: InstallGuideProps) {
  const [activeSection, setActiveSection] = useState<Section>('local');

  const sections: { key: Section; icon: string; label: string }[] = [
    { key: 'local', icon: '💻', label: 'Локально' },
    { key: 'server', icon: '🖥️', label: 'Сервер' },
    { key: 'remote', icon: '🌐', label: 'Удалённо' },
    { key: 'docker', icon: '🐳', label: 'Docker' },
    { key: 'telegram', icon: '📱', label: 'Telegram' },
    { key: 'security', icon: '🔒', label: 'Безопасность' },
  ];

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 rounded-xl border border-gray-600 w-full max-w-5xl shadow-2xl max-h-[95vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <div>
            <h2 className="text-xl font-bold">📖 Инструкция по установке и развёртыванию</h2>
            <p className="text-xs text-gray-400 mt-1">
              Пошаговое руководство для установки на сервер и настройки удалённого доступа
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-gray-700 hover:bg-gray-600 flex items-center justify-center text-lg transition-colors"
          >
            ✕
          </button>
        </div>

        <div className="flex flex-1 overflow-hidden">
          {/* Sidebar */}
          <div className="w-48 bg-gray-900/50 border-r border-gray-700 p-2 overflow-y-auto flex-shrink-0">
            {sections.map(s => (
              <button
                key={s.key}
                onClick={() => setActiveSection(s.key)}
                className={`w-full text-left px-3 py-2 rounded-lg text-sm mb-1 transition-colors ${
                  activeSection === s.key
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-300 hover:bg-gray-700'
                }`}
              >
                <span className="mr-2">{s.icon}</span>
                {s.label}
              </button>
            ))}
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {activeSection === 'local' && <LocalSection />}
            {activeSection === 'server' && <ServerSection />}
            {activeSection === 'remote' && <RemoteSection />}
            {activeSection === 'docker' && <DockerSection />}
            {activeSection === 'telegram' && <TelegramSection />}
            {activeSection === 'security' && <SecuritySection />}
          </div>
        </div>
      </div>
    </div>
  );
}

function CodeBlock({ children, lang = 'bash' }: { children: string; lang?: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="relative group my-2">
      <pre className="bg-gray-900 border border-gray-700 rounded-lg p-3 overflow-x-auto text-xs">
        <code className="text-green-400">{children}</code>
      </pre>
      <span className="absolute top-1 right-1 text-[10px] bg-gray-700 px-1.5 py-0.5 rounded text-gray-400">
        {lang}
      </span>
      <button
        onClick={() => {
          navigator.clipboard.writeText(children);
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        }}
        className="absolute top-1 right-12 text-[10px] bg-blue-600 px-2 py-0.5 rounded text-white opacity-0 group-hover:opacity-100 transition-opacity"
      >
        {copied ? '✓ Скопировано' : '📋 Копировать'}
      </button>
    </div>
  );
}

function Step({ num, title, children }: { num: number; title: string; children: React.ReactNode }) {
  return (
    <div className="mb-4">
      <div className="flex items-center gap-2 mb-2">
        <span className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center text-sm font-bold flex-shrink-0">
          {num}
        </span>
        <h4 className="font-bold">{title}</h4>
      </div>
      <div className="ml-9 text-sm text-gray-300">{children}</div>
    </div>
  );
}

function InfoBox({ type, children }: { type: 'info' | 'warning' | 'success'; children: React.ReactNode }) {
  const styles = {
    info: 'bg-blue-900/20 border-blue-700 text-blue-300',
    warning: 'bg-yellow-900/20 border-yellow-700 text-yellow-300',
    success: 'bg-green-900/20 border-green-700 text-green-300',
  };
  const icons = { info: 'ℹ️', warning: '⚠️', success: '✅' };
  return (
    <div className={`p-3 rounded-lg border text-xs my-3 ${styles[type]}`}>
      <span className="mr-1">{icons[type]}</span>
      {children}
    </div>
  );
}

function LocalSection() {
  return (
    <div>
      <h3 className="text-lg font-bold mb-4">💻 Быстрый старт (локально)</h3>

      <Step num={1} title="Установите Node.js">
        <p>Скачайте с{' '}
          <a href="https://nodejs.org" target="_blank" rel="noopener noreferrer" className="text-blue-400 underline">
            nodejs.org
          </a> (версия 18 или новее, LTS)
        </p>
        <p className="mt-1">Проверка установки:</p>
        <CodeBlock>{`node --version
npm --version`}</CodeBlock>
      </Step>

      <Step num={2} title="Скопируйте проект">
        <p>Распакуйте файлы проекта в любую папку на компьютере.</p>
      </Step>

      <Step num={3} title="Установите зависимости">
        <p>Откройте терминал (cmd/PowerShell) в папке проекта:</p>
        <CodeBlock>{`npm install`}</CodeBlock>
      </Step>

      <Step num={4} title="Запустите приложение">
        <p>Режим разработки:</p>
        <CodeBlock>{`npm run dev`}</CodeBlock>
        <p className="mt-1">Или соберите и запустите production-версию:</p>
        <CodeBlock>{`npm run build
npm run preview`}</CodeBlock>
        <p className="mt-1">Откройте в браузере: <code className="bg-gray-700 px-1 rounded">http://localhost:5173</code></p>
      </Step>

      <InfoBox type="success">
        Готово! Приложение работает локально. Для доступа с других компьютеров в сети — используйте раздел «Сервер».
      </InfoBox>
    </div>
  );
}

function ServerSection() {
  return (
    <div>
      <h3 className="text-lg font-bold mb-4">🖥️ Установка на внутренний сервер</h3>

      <div className="mb-4 p-3 bg-gray-700/50 rounded-lg">
        <p className="font-bold text-sm mb-1">📋 Требования:</p>
        <ul className="text-xs text-gray-300 space-y-1">
          <li>• ОС: Ubuntu 20.04+ / Debian 11+ / CentOS 8+</li>
          <li>• RAM: от 512 MB</li>
          <li>• Диск: от 5 GB</li>
          <li>• Сеть: доступ в интернет (для установки пакетов)</li>
        </ul>
      </div>

      <Step num={1} title="Подключитесь к серверу">
        <CodeBlock>{`ssh user@server-ip`}</CodeBlock>
      </Step>

      <Step num={2} title="Установите Node.js">
        <CodeBlock>{`# Обновление системы
sudo apt update && sudo apt upgrade -y

# Установка Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Проверка
node --version
npm --version`}</CodeBlock>
      </Step>

      <Step num={3} title="Установите Nginx">
        <CodeBlock>{`sudo apt install -y nginx
sudo systemctl enable nginx
sudo systemctl start nginx`}</CodeBlock>
      </Step>

      <Step num={4} title="Разместите приложение">
        <CodeBlock>{`# Создайте папку
sudo mkdir -p /var/www/tpa-monitor
sudo chown $USER:$USER /var/www/tpa-monitor

# Скопируйте файлы проекта (или git clone)
cd /var/www/tpa-monitor
# ... скопируйте файлы ...

# Установите и соберите
npm install
npm run build`}</CodeBlock>
      </Step>

      <Step num={5} title="Настройте Nginx">
        <p>Создайте конфиг:</p>
        <CodeBlock>{`sudo nano /etc/nginx/sites-available/tpa-monitor`}</CodeBlock>
        <p className="mt-2">Вставьте:</p>
        <CodeBlock lang="nginx">{`server {
    listen 80;
    server_name _;  # или ваш домен/IP

    root /var/www/tpa-monitor/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }
}`}</CodeBlock>
        <p className="mt-2">Активируйте:</p>
        <CodeBlock>{`sudo ln -s /etc/nginx/sites-available/tpa-monitor /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl reload nginx`}</CodeBlock>
      </Step>

      <Step num={6} title="Откройте порты">
        <CodeBlock>{`sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 22/tcp
sudo ufw enable`}</CodeBlock>
      </Step>

      <InfoBox type="success">
        Приложение доступно по адресу <code className="bg-gray-700 px-1 rounded">http://IP-СЕРВЕРА</code> в локальной сети!
      </InfoBox>
    </div>
  );
}

function RemoteSection() {
  return (
    <div>
      <h3 className="text-lg font-bold mb-4">🌐 Удалённый доступ через интернет</h3>

      <div className="mb-4 p-3 bg-blue-900/20 border border-blue-700 rounded-lg">
        <p className="text-sm text-blue-300 font-bold mb-2">🏆 Рекомендуемый способ: Cloudflare Tunnel</p>
        <p className="text-xs text-blue-200">
          Бесплатно, безопасно, не нужно открывать порты или покупать домен для начала.
        </p>
      </div>

      <h4 className="font-bold mb-2 text-yellow-400">⚡ Способ 1: Cloudflare Tunnel (рекомендуется)</h4>
      <Step num={1} title="Установите cloudflared">
        <CodeBlock>{`# Linux
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o cloudflared
chmod +x cloudflared
sudo mv cloudflared /usr/local/bin/

# Windows: скачать с https://github.com/cloudflare/cloudflared/releases`}</CodeBlock>
      </Step>

      <Step num={2} title="Запустите туннель">
        <CodeBlock>{`cloudflared tunnel --url http://localhost:80`}</CodeBlock>
        <p className="mt-1">Вы получите публичную ссылку вида <code className="bg-gray-700 px-1 rounded">https://xxx.trycloudflare.com</code></p>
      </Step>

      <InfoBox type="success">
        Эта ссылка доступна из любой точки интернета! Отправьте её сотрудникам.
      </InfoBox>

      <div className="border-t border-gray-700 my-6 pt-4">
        <h4 className="font-bold mb-2 text-green-400">🌐 Способ 2: VPS + домен + HTTPS</h4>
        <Step num={1} title="Арендуйте VPS">
          <p>Рекомендуемые провайдеры (от 200₽/мес):</p>
          <ul className="list-disc list-inside mt-1 space-y-0.5">
            <li>Timeweb Cloud — timeweb.cloud</li>
            <li>Beget — beget.com</li>
            <li>Selectel — selectel.ru</li>
            <li>Hetzner — hetzner.com (Европа)</li>
          </ul>
          <p className="mt-1">Минимум: 1 vCPU, 1 GB RAM, Ubuntu 22.04</p>
        </Step>

        <Step num={2} title="Купите домен">
          <p>Например, на reg.ru или namecheap.com (от 199₽/год)</p>
          <p className="mt-1">Настройте DNS A-запись: <code className="bg-gray-700 px-1 rounded">tpa.ваш-домен.ru</code> → IP VPS</p>
        </Step>

        <Step num={3} title="Установите SSL (бесплатно)">
          <CodeBlock>{`sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d tpa.ваш-домен.ru`}</CodeBlock>
        </Step>

        <InfoBox type="success">
          Готово! Приложение доступно по <code className="bg-gray-700 px-1 rounded">https://tpa.ваш-домен.ru</code>
        </InfoBox>
      </div>

      <div className="border-t border-gray-700 my-6 pt-4">
        <h4 className="font-bold mb-2 text-purple-400">🚀 Способ 3: Ngrok (быстрый тест)</h4>
        <CodeBlock>{`# Установка
curl -s https://ngrok-agent.s3.amazonaws.com/ngrok.asc | sudo tee /etc/apt/trusted.gpg.d/ngrok.asc
sudo apt update && sudo apt install ngrok

# Запуск
ngrok http 80`}</CodeBlock>
        <InfoBox type="warning">
          Бесплатная версия: ссылка меняется при перезапуске. Подходит только для тестов.
        </InfoBox>
      </div>
    </div>
  );
}

function DockerSection() {
  return (
    <div>
      <h3 className="text-lg font-bold mb-4">🐳 Docker-развёртывание</h3>

      <InfoBox type="info">
        Самый простой способ для продакшена — всё работает в контейнере, легко обновлять и переносить.
      </InfoBox>

      <Step num={1} title="Установите Docker">
        <CodeBlock>{`# Ubuntu/Debian
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
# Перелогиньтесь!

# Проверка
docker --version
docker compose version`}</CodeBlock>
      </Step>

      <Step num={2} title="Подготовьте файлы">
        <p>Убедитесь, что в папке проекта есть:</p>
        <ul className="list-disc list-inside mt-1 space-y-0.5">
          <li><code className="bg-gray-700 px-1 rounded">docker/Dockerfile</code></li>
          <li><code className="bg-gray-700 px-1 rounded">docker/docker-compose.yml</code></li>
          <li><code className="bg-gray-700 px-1 rounded">docker/nginx.conf</code></li>
        </ul>
      </Step>

      <Step num={3} title="Запустите">
        <CodeBlock>{`cd /path/to/project
docker compose -f docker/docker-compose.yml up -d`}</CodeBlock>
        <p className="mt-1">Приложение доступно на <code className="bg-gray-700 px-1 rounded">http://localhost:80</code></p>
      </Step>

      <Step num={4} title="Полезные команды">
        <CodeBlock>{`# Логи
docker compose -f docker/docker-compose.yml logs -f

# Перезапуск
docker compose -f docker/docker-compose.yml restart

# Остановка
docker compose -f docker/docker-compose.yml down

# Обновление
docker compose -f docker/docker-compose.yml pull
docker compose -f docker/docker-compose.yml up -d --build`}</CodeBlock>
      </Step>

      <InfoBox type="success">
        Docker-контейнер автоматически перезапускается при сбое и обновляется при наличии новой версии.
      </InfoBox>
    </div>
  );
}

function TelegramSection() {
  return (
    <div>
      <h3 className="text-lg font-bold mb-4">📱 Настройка Telegram-бота</h3>

      <Step num={1} title="Создайте бота">
        <ol className="list-decimal list-inside space-y-1">
          <li>
            Откройте{' '}
            <a href="https://t.me/BotFather" target="_blank" rel="noopener noreferrer" className="text-blue-400 underline">
              @BotFather
            </a>{' '}
            в Telegram
          </li>
          <li>Отправьте команду <code className="bg-gray-700 px-1 rounded">/newbot</code></li>
          <li>Введите имя бота (например: <i>ТПА Мониторинг Цех</i>)</li>
          <li>Введите username (должен заканчиваться на <code className="bg-gray-700 px-1 rounded">bot</code>)</li>
          <li>Скопируйте токен вида <code className="bg-gray-700 px-1 rounded">123456:ABC-DEF...</code></li>
        </ol>
      </Step>

      <Step num={2} title="Получите Chat ID специалистов">
        <ol className="list-decimal list-inside space-y-1">
          <li>
            Каждый специалист открывает{' '}
            <a href="https://t.me/userinfobot" target="_blank" rel="noopener noreferrer" className="text-blue-400 underline">
              @userinfobot
            </a>
          </li>
          <li>Нажимает <b>Start</b></li>
          <li>Копирует свой <b>Id</b> (число)</li>
          <li>Сообщает ID администратору</li>
        </ol>
      </Step>

      <Step num={3} title="Настройте в приложении">
        <ol className="list-decimal list-inside space-y-1">
          <li>Войдите как администратор</li>
          <li>Нажмите <b>🔔 Уведомления</b></li>
          <li>Вставьте Bot Token</li>
          <li>Включите Telegram</li>
          <li>Для каждого специалиста введите его Chat ID</li>
          <li>Нажмите <b>💾 Сохранить</b></li>
        </ol>
      </Step>

      <Step num={4} title="Важно!">
        <InfoBox type="warning">
          Каждый специалист должен <b>один раз</b> написать вашему боту <code className="bg-gray-700 px-1 rounded">/start</code> в Telegram, иначе бот не сможет ему писать (политика Telegram).
        </InfoBox>
      </Step>

      <Step num={5} title="Проверка">
        <p>В командной строке:</p>
        <CodeBlock>{`curl -X POST https://api.telegram.org/bot<ТОКЕН>/sendMessage \\
  -H "Content-Type: application/json" \\
  -d '{"chat_id":"<CHAT_ID>","text":"Тест"}'`}</CodeBlock>
        <p className="mt-1">Если сообщение пришло — всё работает!</p>
      </Step>
    </div>
  );
}

function SecuritySection() {
  return (
    <div>
      <h3 className="text-lg font-bold mb-4">🔒 Безопасность</h3>

      <div className="space-y-3">
        <div className="p-3 bg-red-900/20 border border-red-700 rounded-lg">
          <h4 className="font-bold text-red-300 mb-2">🚨 Обязательно:</h4>
          <ul className="text-xs text-red-200 space-y-1 list-disc list-inside">
            <li>Смените пароль админа (по умолчанию: admin123)</li>
            <li>Используйте HTTPS (не HTTP)</li>
            <li>Не храните токен Telegram-бота в открытом доступе</li>
            <li>Регулярно обновляйте систему</li>
          </ul>
        </div>

        <div className="p-3 bg-yellow-900/20 border border-yellow-700 rounded-lg">
          <h4 className="font-bold text-yellow-300 mb-2">⚠️ Рекомендуется:</h4>
          <ul className="text-xs text-yellow-200 space-y-1 list-disc list-inside">
            <li>Ограничьте доступ по IP (только локальная сеть + VPN)</li>
            <li>Используйте Cloudflare Tunnel (скрывает IP сервера)</li>
            <li>Настройте fail2ban для защиты от взлома</li>
            <li>Делайте резервные копии настроек</li>
            <li>Включите двухфакторную аутентификацию на сервере</li>
          </ul>
        </div>

        <div className="p-3 bg-green-900/20 border border-green-700 rounded-lg">
          <h4 className="font-bold text-green-300 mb-2">✅ Ограничение доступа по IP:</h4>
          <p className="text-xs text-green-200 mb-2">Добавьте в конфиг Nginx:</p>
          <CodeBlock lang="nginx">{`location / {
    allow 192.168.1.0/24;   # Локальная сеть
    allow 10.8.0.0/24;      # VPN
    deny all;               # Остальным запрет
    try_files $uri $uri/ /index.html;
}`}</CodeBlock>
        </div>

        <div className="p-3 bg-blue-900/20 border border-blue-700 rounded-lg">
          <h4 className="font-bold text-blue-300 mb-2">🔄 Резервное копирование:</h4>
          <CodeBlock>{`#!/bin/bash
# Скрипт бэкапа (добавьте в crontab)
BACKUP_DIR="/backup/tpa-monitor"
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p $BACKUP_DIR
tar -czf $BACKUP_DIR/tpa-$DATE.tar.gz /var/www/tpa-monitor`}</CodeBlock>
        </div>
      </div>
    </div>
  );
}
