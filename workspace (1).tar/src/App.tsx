import { useState, useEffect, useCallback, useRef } from 'react';
import { TPAMachine, SpecialistType, AppSettings, NotificationLog } from './types';
import {
  SPECIALISTS_LIST as SPECIALISTS,
  notifySpecialist,
  requestNotificationPermission,
  testTelegramConnection,
  getDefaultNotificationSettings,
} from './notifications';
import InstallGuide from './InstallGuide';

const THEMES = {
  dark: {
    name: 'Тёмная',
    bg: 'bg-gray-900',
    header: 'bg-gray-800',
    border: 'border-gray-700',
    card: 'bg-gray-800',
    accent: 'text-blue-400',
    accentBg: 'bg-blue-600',
  },
  blue: {
    name: 'Синяя',
    bg: 'bg-slate-900',
    header: 'bg-slate-800',
    border: 'border-slate-700',
    card: 'bg-slate-800',
    accent: 'text-sky-400',
    accentBg: 'bg-sky-600',
  },
  green: {
    name: 'Зелёная',
    bg: 'bg-emerald-950',
    header: 'bg-emerald-900',
    border: 'border-emerald-700',
    card: 'bg-emerald-900',
    accent: 'text-emerald-400',
    accentBg: 'bg-emerald-600',
  },
  industrial: {
    name: 'Индустриальная',
    bg: 'bg-zinc-900',
    header: 'bg-zinc-800',
    border: 'border-zinc-700',
    card: 'bg-zinc-800',
    accent: 'text-amber-400',
    accentBg: 'bg-amber-600',
  },
};

const ERROR_TIMEOUT = 120;

function createInitialMachines(): TPAMachine[] {
  return Array.from({ length: 25 }, (_, i) => ({
    id: i + 1,
    name: `ТПА-${String(i + 1).padStart(2, '0')}`,
    projectName: `Проект ${String.fromCharCode(65 + (i % 26))}-${Math.floor(i / 26) + 1}`,
    cycleTime: Math.floor(Math.random() * 30) + 20,
    lastSignalTime: Date.now(),
    isRunning: true,
    hasError: false,
    itemsPerCycle: 1,
    totalProduced: 0,
    currentCycleCount: 0,
    assignedSpecialists: [],
    specialistsCalledAt: null,
  }));
}

const DEFAULT_SETTINGS: AppSettings = {
  title: 'Мониторинг ТПА — Цех литья',
  subtitle: 'Система мониторинга термопластавтоматов в реальном времени',
  theme: 'dark',
  adminPassword: 'admin123',
  notifications: getDefaultNotificationSettings(),
};

function App() {
  const [machines, setMachines] = useState<TPAMachine[]>(createInitialMachines);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [currentTime, setCurrentTime] = useState(Date.now());
  const [totalProduction, setTotalProduction] = useState(0);
  const [showSpecialistModal, setShowSpecialistModal] = useState<number | null>(null);
  const [filter, setFilter] = useState<'all' | 'running' | 'error' | 'stopped'>('all');

  // Auth
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // Admin editing
  const [editMode, setEditMode] = useState(false);
  const [editingMachine, setEditingMachine] = useState<number | null>(null);
  const [editName, setEditName] = useState('');
  const [editProject, setEditProject] = useState('');
  const [editCycleTime, setEditCycleTime] = useState(30);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [tempTitle, setTempTitle] = useState('');
  const [tempSubtitle, setTempSubtitle] = useState('');
  const [tempTheme, setTempTheme] = useState<AppSettings['theme']>('dark');

  // Notifications
  const [notificationLogs, setNotificationLogs] = useState<NotificationLog[]>([]);
  const [showNotificationsModal, setShowNotificationsModal] = useState(false);
  const [showLogsModal, setShowLogsModal] = useState(false);
  const [tempNotifSettings, setTempNotifSettings] = useState(getDefaultNotificationSettings());
  const [testResult, setTestResult] = useState<{ ok: boolean; error?: string } | null>(null);
  const [testing, setTesting] = useState(false);
  const logIdRef = useRef(0);

  // Install guide
  const [showInstallGuide, setShowInstallGuide] = useState(false);

  const theme = THEMES[settings.theme];

  // Update time
  useEffect(() => {
    const interval = setInterval(() => setCurrentTime(Date.now()), 1000);
    return () => clearInterval(interval);
  }, []);

  // Request notification permission on load
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      // Don't auto-request, let user click the button
    }
  }, []);

  // Check errors
  useEffect(() => {
    setMachines(prev =>
      prev.map(machine => {
        if (!machine.isRunning || machine.lastSignalTime === null) return machine;
        const elapsed = (currentTime - machine.lastSignalTime) / 1000;
        if (elapsed > ERROR_TIMEOUT && !machine.hasError) {
          return { ...machine, hasError: true, isRunning: false };
        }
        return machine;
      })
    );
  }, [currentTime]);

  // Total production
  useEffect(() => {
    const total = machines.reduce((sum, m) => sum + m.totalProduced, 0);
    setTotalProduction(total);
  }, [machines]);

  // Simulate signal
  const simulateSignal = useCallback((machineId: number) => {
    setMachines(prev =>
      prev.map(m => {
        if (m.id !== machineId) return m;
        return {
          ...m,
          lastSignalTime: Date.now(),
          hasError: false,
          isRunning: true,
          currentCycleCount: m.currentCycleCount + 1,
          totalProduced: m.totalProduced + m.itemsPerCycle,
        };
      })
    );
  }, []);

  const toggleMachine = useCallback((machineId: number) => {
    setMachines(prev =>
      prev.map(m => {
        if (m.id !== machineId) return m;
        if (m.isRunning) return { ...m, isRunning: false };
        return { ...m, isRunning: true, lastSignalTime: Date.now(), hasError: false };
      })
    );
  }, []);

  const setItemsPerCycle = useCallback((machineId: number, value: number) => {
    setMachines(prev =>
      prev.map(m => (m.id === machineId ? { ...m, itemsPerCycle: Math.max(1, value) } : m))
    );
  }, []);

  const addNotificationLog = useCallback(
    (machineName: string, specialist: SpecialistType, method: string, status: 'sent' | 'failed', message: string) => {
      logIdRef.current += 1;
      const newLog: NotificationLog = {
        id: logIdRef.current,
        timestamp: Date.now(),
        machineName,
        specialist,
        method,
        status,
        message,
      };
      setNotificationLogs(prev => [newLog, ...prev].slice(0, 50));
    },
    []
  );

  const callSpecialist = useCallback(
    async (machineId: number, specialist: SpecialistType) => {
      const machine = machines.find(m => m.id === machineId);
      if (!machine) return;

      const already = machine.assignedSpecialists.includes(specialist);
      const action = already ? 'cancel' : 'call';

      setMachines(prev =>
        prev.map(m => {
          if (m.id !== machineId) return m;
          const newSpecialists = already
            ? m.assignedSpecialists.filter(s => s !== specialist)
            : [...m.assignedSpecialists, specialist];
          return {
            ...m,
            assignedSpecialists: newSpecialists,
            specialistsCalledAt: newSpecialists.length > 0 ? Date.now() : null,
          };
        })
      );

      const specInfo = SPECIALISTS.find(s => s.type === specialist);
      if (!specInfo) return;

      const result = await notifySpecialist(
        settings.notifications,
        machine.name,
        machine.projectName,
        specInfo,
        action
      );
      addNotificationLog(machine.name, specialist, result.method, result.status, result.message);
    },
    [machines, settings.notifications, addNotificationLog]
  );

  const clearOneSpecialist = useCallback(
    async (machineId: number, specialist: SpecialistType) => {
      const machine = machines.find(m => m.id === machineId);
      if (!machine) return;

      setMachines(prev =>
        prev.map(m => {
          if (m.id !== machineId) return m;
          const newSpecialists = m.assignedSpecialists.filter(s => s !== specialist);
          return {
            ...m,
            assignedSpecialists: newSpecialists,
            specialistsCalledAt: newSpecialists.length > 0 ? m.specialistsCalledAt : null,
          };
        })
      );

      const specInfo = SPECIALISTS.find(s => s.type === specialist);
      if (!specInfo) return;

      const result = await notifySpecialist(
        settings.notifications,
        machine.name,
        machine.projectName,
        specInfo,
        'cancel'
      );
      addNotificationLog(machine.name, specialist, result.method, result.status, result.message);
    },
    [machines, settings.notifications, addNotificationLog]
  );

  const clearAllSpecialists = useCallback(
    async (machineId: number) => {
      const machine = machines.find(m => m.id === machineId);
      if (!machine) return;
      const specialistsToCancel = [...machine.assignedSpecialists];

      setMachines(prev =>
        prev.map(m =>
          m.id === machineId
            ? { ...m, assignedSpecialists: [], specialistsCalledAt: null }
            : m
        )
      );

      for (const specType of specialistsToCancel) {
        const specInfo = SPECIALISTS.find(s => s.type === specType);
        if (!specInfo) continue;
        const result = await notifySpecialist(
          settings.notifications,
          machine.name,
          machine.projectName,
          specInfo,
          'cancel'
        );
        addNotificationLog(machine.name, specType, result.method, result.status, result.message);
      }
    },
    [machines, settings.notifications, addNotificationLog]
  );

  const resetError = useCallback((machineId: number) => {
    setMachines(prev =>
      prev.map(m =>
        m.id === machineId
          ? { ...m, hasError: false, isRunning: true, lastSignalTime: Date.now() }
          : m
      )
    );
  }, []);

  // Auto simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setMachines(prev =>
        prev.map(m => {
          if (!m.isRunning || m.hasError || !m.lastSignalTime) return m;
          const elapsed = (Date.now() - m.lastSignalTime) / 1000;
          if (elapsed >= m.cycleTime) {
            return {
              ...m,
              lastSignalTime: Date.now(),
              currentCycleCount: m.currentCycleCount + 1,
              totalProduced: m.totalProduced + m.itemsPerCycle,
            };
          }
          return m;
        })
      );
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Login
  const handleLogin = () => {
    if (loginUsername === 'admin' && loginPassword === settings.adminPassword) {
      setIsLoggedIn(true);
      setShowLoginModal(false);
      setLoginError('');
      setLoginUsername('');
      setLoginPassword('');
    } else {
      setLoginError('Неверный логин или пароль');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setEditMode(false);
  };

  // Edit machine
  const openEditMachine = (machineId: number) => {
    const machine = machines.find(m => m.id === machineId);
    if (machine) {
      setEditingMachine(machineId);
      setEditName(machine.name);
      setEditProject(machine.projectName);
      setEditCycleTime(machine.cycleTime);
    }
  };

  const saveEditMachine = () => {
    if (editingMachine === null) return;
    setMachines(prev =>
      prev.map(m =>
        m.id === editingMachine
          ? { ...m, name: editName, projectName: editProject, cycleTime: editCycleTime }
          : m
      )
    );
    setEditingMachine(null);
  };

  // Settings
  const openSettings = () => {
    setTempTitle(settings.title);
    setTempSubtitle(settings.subtitle);
    setTempTheme(settings.theme);
    setShowSettingsModal(true);
  };

  const openNotificationsSettings = () => {
    setTempNotifSettings(settings.notifications);
    setTestResult(null);
    setShowNotificationsModal(true);
  };

  const saveSettings = () => {
    setSettings(prev => ({
      ...prev,
      title: tempTitle,
      subtitle: tempSubtitle,
      theme: tempTheme,
    }));
    setShowSettingsModal(false);
  };

  const getElapsedSeconds = (machine: TPAMachine) => {
    if (!machine.lastSignalTime) return 0;
    return Math.floor((currentTime - machine.lastSignalTime) / 1000);
  };

  const getProgress = (machine: TPAMachine) => {
    const elapsed = getElapsedSeconds(machine);
    return Math.min((elapsed / machine.cycleTime) * 100, 100);
  };

  const getMachineStatus = (machine: TPAMachine) => {
    if (machine.hasError) return 'error';
    if (!machine.isRunning) return 'stopped';
    return 'running';
  };

  const filteredMachines = machines.filter(m => {
    if (filter === 'all') return true;
    return getMachineStatus(m) === filter;
  });

  const errorCount = machines.filter(m => m.hasError).length;
  const runningCount = machines.filter(m => m.isRunning && !m.hasError).length;
  const stoppedCount = machines.filter(m => !m.isRunning && !m.hasError).length;

  return (
    <div className={`min-h-screen ${theme.bg} text-white`}>
      {/* Header */}
      <header className={`${theme.header} border-b ${theme.border} shadow-lg`}>
        <div className="max-w-[1920px] mx-auto px-4 py-4">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
              <h1 className={`text-2xl font-bold ${theme.accent}`}>
                🏭 {settings.title}
              </h1>
              <p className="text-gray-400 text-sm mt-1">{settings.subtitle}</p>
            </div>
            <div className="flex items-center gap-4 flex-wrap">
              <div className="bg-gray-700/50 rounded-lg px-4 py-2">
                <span className="text-gray-400 text-xs">Всего выпущено</span>
                <p className="text-xl font-bold text-green-400">
                  {totalProduction.toLocaleString()} шт
                </p>
              </div>
              <div className="flex gap-2 flex-wrap">
                <span className="bg-green-600/20 text-green-400 px-3 py-1 rounded-full text-sm">
                  ● Работает: {runningCount}
                </span>
                <span className="bg-red-600/20 text-red-400 px-3 py-1 rounded-full text-sm">
                  ● Ошибки: {errorCount}
                </span>
                <span className="bg-gray-600/20 text-gray-400 px-3 py-1 rounded-full text-sm">
                  ● Стоп: {stoppedCount}
                </span>
                {isLoggedIn && (
                  <span className="bg-teal-600/20 text-teal-400 px-3 py-1 rounded-full text-sm flex items-center gap-1">
                    🔔
                    {settings.notifications.telegramEnabled ? '📱' : ''}
                    {settings.notifications.webNotificationsEnabled ? '🖥️' : ''}
                    {settings.notifications.soundEnabled ? '🔊' : ''}
                  </span>
                )}
              </div>
              {/* Auth buttons */}
              <div className="flex gap-2">
                {isLoggedIn ? (
                  <>
                    <button
                      onClick={() => setEditMode(!editMode)}
                      className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                        editMode
                          ? 'bg-yellow-500 text-black'
                          : 'bg-gray-600 text-white hover:bg-gray-500'
                      }`}
                    >
                      {editMode ? '✏️ Режим редактирования' : '✏️ Редактировать'}
                    </button>
                    <button
                      onClick={() => setShowInstallGuide(true)}
                      className="px-3 py-1.5 rounded-lg text-sm font-medium bg-indigo-600 text-white hover:bg-indigo-500 transition-all"
                    >
                      📖 Инструкция
                    </button>
                    <button
                      onClick={openNotificationsSettings}
                      className="px-3 py-1.5 rounded-lg text-sm font-medium bg-teal-600 text-white hover:bg-teal-500 transition-all"
                    >
                      🔔 Уведомления
                    </button>
                    <button
                      onClick={() => setShowLogsModal(true)}
                      className="px-3 py-1.5 rounded-lg text-sm font-medium bg-gray-600 text-white hover:bg-gray-500 transition-all relative"
                    >
                      📋 Логи
                      {notificationLogs.length > 0 && (
                        <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-[10px] flex items-center justify-center">
                          {notificationLogs.length > 9 ? '9+' : notificationLogs.length}
                        </span>
                      )}
                    </button>
                    <button
                      onClick={openSettings}
                      className="px-3 py-1.5 rounded-lg text-sm font-medium bg-gray-600 text-white hover:bg-gray-500 transition-all"
                    >
                      ⚙️ Настройки
                    </button>
                    <button
                      onClick={handleLogout}
                      className="px-3 py-1.5 rounded-lg text-sm font-medium bg-red-600/80 text-white hover:bg-red-500 transition-all"
                    >
                      🚪 Выйти
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      onClick={async () => {
                        const granted = await requestNotificationPermission();
                        if (granted) {
                          alert('✅ Уведомления разрешены!');
                        } else {
                          alert('❌ Уведомления заблокированы в браузере');
                        }
                      }}
                      className="px-3 py-1.5 rounded-lg text-sm font-medium bg-teal-600/80 text-white hover:bg-teal-500 transition-all"
                    >
                      🔔 Разрешить уведомления
                    </button>
                    <button
                      onClick={() => setShowInstallGuide(true)}
                      className="px-3 py-1.5 rounded-lg text-sm font-medium bg-indigo-600 text-white hover:bg-indigo-500 transition-all"
                    >
                      📖 Инструкция
                    </button>
                    <button
                      onClick={() => setShowLoginModal(true)}
                      className="px-3 py-1.5 rounded-lg text-sm font-medium bg-blue-600 text-white hover:bg-blue-500 transition-all"
                    >
                      🔐 Вход для админа
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Filters */}
      <div className="max-w-[1920px] mx-auto px-4 py-3">
        <div className="flex gap-2 flex-wrap">
          {[
            { key: 'all', label: 'Все', count: 25 },
            { key: 'running', label: 'Работают', count: runningCount },
            { key: 'error', label: 'С ошибками', count: errorCount },
            { key: 'stopped', label: 'Остановлены', count: stoppedCount },
          ].map(f => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key as typeof filter)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                filter === f.key
                  ? `${theme.accentBg} text-white shadow-lg`
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              {f.label} ({f.count})
            </button>
          ))}
        </div>
      </div>

      {/* Machines Grid */}
      <div className="max-w-[1920px] mx-auto px-4 pb-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {filteredMachines.map(machine => {
            const elapsed = getElapsedSeconds(machine);
            const progress = getProgress(machine);
            const status = getMachineStatus(machine);
            const timeLeft = Math.max(0, machine.cycleTime - elapsed);

            return (
              <div
                key={machine.id}
                className={`relative rounded-xl border-2 overflow-hidden transition-all duration-300 ${
                  status === 'error'
                    ? 'border-red-500 bg-gray-800 shadow-lg shadow-red-500/20 animate-pulse'
                    : status === 'running'
                    ? 'border-green-500/50 bg-gray-800'
                    : 'border-gray-600 bg-gray-800/70'
                }`}
              >
                {/* Status bar */}
                <div
                  className={`absolute top-0 left-0 right-0 h-1 ${
                    status === 'error'
                      ? 'bg-red-500'
                      : status === 'running'
                      ? 'bg-green-500'
                      : 'bg-gray-500'
                  }`}
                />

                {/* Admin edit button */}
                {editMode && (
                  <button
                    onClick={() => openEditMachine(machine.id)}
                    className="absolute top-2 right-2 z-10 w-7 h-7 rounded-full bg-yellow-500 text-black flex items-center justify-center text-xs font-bold hover:bg-yellow-400 transition-colors shadow-lg"
                  >
                    ✏️
                  </button>
                )}

                {/* Header */}
                <div className="p-3 pb-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-bold text-lg">{machine.name}</h3>
                      <p className="text-xs text-gray-400 mt-0.5">
                        📋 {machine.projectName}
                      </p>
                    </div>
                    <div className="flex items-center gap-1">
                      {status === 'error' && (
                        <span className="text-red-400 text-xs animate-pulse">⚠️ ОШИБКА</span>
                      )}
                      {status === 'running' && (
                        <span className="text-green-400 text-xs">● Работает</span>
                      )}
                      {status === 'stopped' && (
                        <span className="text-gray-400 text-xs">○ Стоп</span>
                      )}
                    </div>
                  </div>

                  {machine.assignedSpecialists.length > 0 && (
                    <div className="mt-1 flex flex-wrap items-center gap-1">
                      {machine.assignedSpecialists.map(specType => {
                        const spec = SPECIALISTS.find(s => s.type === specType);
                        if (!spec) return null;
                        return (
                          <div
                            key={specType}
                            className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full text-white ${spec.color}`}
                          >
                            <span>{spec.icon}</span>
                            <span>{spec.label}</span>
                            <button
                              onClick={() => clearOneSpecialist(machine.id, specType)}
                              className="w-4 h-4 rounded-full bg-black/30 hover:bg-black/60 text-white flex items-center justify-center ml-0.5 transition-colors"
                              title={`Убрать: ${spec.label}`}
                            >
                              ✕
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Timer / Error */}
                <div className="px-3 pb-2">
                  {status === 'error' ? (
                    <div className="bg-red-900/30 border border-red-700 rounded-lg p-2 text-center">
                      <p className="text-red-400 font-bold text-sm">⚠️ Сигнал не получен</p>
                      <p className="text-red-300 text-xs">
                        Прошло: {Math.floor(elapsed / 60)}:{String(elapsed % 60).padStart(2, '0')}
                      </p>
                      <button
                        onClick={() => resetError(machine.id)}
                        className="mt-2 px-3 py-1 bg-red-600 hover:bg-red-500 rounded text-xs font-medium transition-colors"
                      >
                        Сбросить ошибку
                      </button>
                    </div>
                  ) : (
                    <div>
                      <div className="flex justify-between text-xs text-gray-400 mb-1">
                        <span>Цикл: {machine.cycleTime}с</span>
                        <span>
                          {status === 'running' ? `Осталось: ${timeLeft}с` : 'Остановлен'}
                        </span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full transition-all duration-1000 ${
                            progress > 80 ? 'bg-yellow-400' : 'bg-blue-400'
                          }`}
                          style={{ width: `${status === 'running' ? progress : 0}%` }}
                        />
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        Время от сигнала: {Math.floor(elapsed / 60)}:
                        {String(elapsed % 60).padStart(2, '0')}
                      </p>
                    </div>
                  )}
                </div>

                {/* Production */}
                <div className="px-3 pb-2">
                  <div className="bg-gray-700/50 rounded-lg p-2">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-gray-400">Изделий/цикл:</span>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => setItemsPerCycle(machine.id, machine.itemsPerCycle - 1)}
                          className="w-5 h-5 rounded bg-gray-600 hover:bg-gray-500 text-xs flex items-center justify-center"
                        >
                          -
                        </button>
                        <input
                          type="number"
                          min="1"
                          max="999"
                          value={machine.itemsPerCycle}
                          onChange={e =>
                            setItemsPerCycle(machine.id, parseInt(e.target.value) || 1)
                          }
                          className="w-12 bg-gray-800 border border-gray-600 rounded text-center text-xs py-0.5 text-white"
                        />
                        <button
                          onClick={() => setItemsPerCycle(machine.id, machine.itemsPerCycle + 1)}
                          className="w-5 h-5 rounded bg-gray-600 hover:bg-gray-500 text-xs flex items-center justify-center"
                        >
                          +
                        </button>
                      </div>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-400">Выпущено:</span>
                      <span className="text-green-400 font-bold">{machine.totalProduced} шт</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-400">Циклов:</span>
                      <span className="text-blue-400">{machine.currentCycleCount}</span>
                    </div>
                  </div>
                </div>

                {/* Controls */}
                <div className="px-3 pb-3 flex gap-1">
                  <button
                    onClick={() => toggleMachine(machine.id)}
                    className={`flex-1 py-1.5 rounded text-xs font-medium transition-colors ${
                      machine.isRunning
                        ? 'bg-red-600/80 hover:bg-red-500 text-white'
                        : 'bg-green-600/80 hover:bg-green-500 text-white'
                    }`}
                  >
                    {machine.isRunning ? '⏹ Стоп' : '▶ Старт'}
                  </button>
                  <button
                    onClick={() => simulateSignal(machine.id)}
                    className="flex-1 py-1.5 rounded bg-blue-600/80 hover:bg-blue-500 text-xs font-medium text-white transition-colors"
                    disabled={!machine.isRunning}
                  >
                    📡 Сигнал
                  </button>
                  {machine.assignedSpecialists.length > 0 ? (
                    <button
                      onClick={() => clearAllSpecialists(machine.id)}
                      className="py-1.5 px-2 rounded bg-red-600/80 hover:bg-red-500 text-xs font-medium text-white transition-colors"
                      title="Отменить всех специалистов"
                    >
                      ❌
                    </button>
                  ) : (
                    <button
                      onClick={() => setShowSpecialistModal(machine.id)}
                      className="py-1.5 px-2 rounded bg-purple-600/80 hover:bg-purple-500 text-xs font-medium text-white transition-colors"
                      title="Вызвать специалиста"
                    >
                      👤
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Login Modal */}
      {showLoginModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-800 rounded-xl border border-gray-600 p-6 w-full max-w-sm shadow-2xl">
            <h3 className="text-xl font-bold mb-1 text-center">🔐 Вход администратора</h3>
            <p className="text-gray-400 text-sm mb-4 text-center">
              Введите учётные данные для доступа
            </p>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Логин</label>
                <input
                  type="text"
                  value={loginUsername}
                  onChange={e => setLoginUsername(e.target.value)}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                  placeholder="admin"
                  onKeyDown={e => e.key === 'Enter' && handleLogin()}
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Пароль</label>
                <input
                  type="password"
                  value={loginPassword}
                  onChange={e => setLoginPassword(e.target.value)}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                  placeholder="••••••"
                  onKeyDown={e => e.key === 'Enter' && handleLogin()}
                />
              </div>
              {loginError && (
                <p className="text-red-400 text-sm text-center">{loginError}</p>
              )}
              <button
                onClick={handleLogin}
                className="w-full py-2 rounded-lg bg-blue-600 hover:bg-blue-500 font-medium transition-colors"
              >
                Войти
              </button>
              <button
                onClick={() => {
                  setShowLoginModal(false);
                  setLoginError('');
                }}
                className="w-full py-2 rounded-lg bg-gray-600 hover:bg-gray-500 font-medium transition-colors"
              >
                Отмена
              </button>
            </div>
            <p className="text-xs text-gray-500 mt-3 text-center">
              Логин: admin | Пароль: admin123
            </p>
          </div>
        </div>
      )}

      {/* Edit Machine Modal */}
      {editingMachine !== null && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-800 rounded-xl border border-gray-600 p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-xl font-bold mb-4">
              ✏️ Редактирование: {machines.find(m => m.id === editingMachine)?.name}
            </h3>
            <div className="space-y-4">
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Номер / Название ТПА</label>
                <input
                  type="text"
                  value={editName}
                  onChange={e => setEditName(e.target.value)}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-1 block">
                  Название проекта на ТПА
                </label>
                <input
                  type="text"
                  value={editProject}
                  onChange={e => setEditProject(e.target.value)}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Время цикла (секунды)</label>
                <input
                  type="number"
                  min="5"
                  max="600"
                  value={editCycleTime}
                  onChange={e => setEditCycleTime(parseInt(e.target.value) || 30)}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>
            <div className="flex gap-2 mt-6">
              <button
                onClick={saveEditMachine}
                className="flex-1 py-2 rounded-lg bg-green-600 hover:bg-green-500 font-medium transition-colors"
              >
                💾 Сохранить
              </button>
              <button
                onClick={() => setEditingMachine(null)}
                className="flex-1 py-2 rounded-lg bg-gray-600 hover:bg-gray-500 font-medium transition-colors"
              >
                Отмена
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Settings Modal */}
      {showSettingsModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-800 rounded-xl border border-gray-600 p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-xl font-bold mb-4">⚙️ Настройки системы</h3>
            <div className="space-y-4">
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Заголовок страницы</label>
                <input
                  type="text"
                  value={tempTitle}
                  onChange={e => setTempTitle(e.target.value)}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Подзаголовок</label>
                <input
                  type="text"
                  value={tempSubtitle}
                  onChange={e => setTempSubtitle(e.target.value)}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-2 block">Тема оформления</label>
                <div className="grid grid-cols-2 gap-2">
                  {(Object.entries(THEMES) as [AppSettings['theme'], typeof THEMES.dark][]).map(
                    ([key, t]) => (
                      <button
                        key={key}
                        onClick={() => setTempTheme(key)}
                        className={`p-3 rounded-lg border-2 transition-all ${
                          tempTheme === key
                            ? 'border-blue-500 bg-blue-500/10'
                            : 'border-gray-600 hover:border-gray-500'
                        }`}
                      >
                        <div
                          className={`w-full h-4 rounded ${t.bg} border border-gray-600 mb-1`}
                        />
                        <span className="text-xs font-medium">{t.name}</span>
                      </button>
                    )
                  )}
                </div>
              </div>
            </div>
            <div className="flex gap-2 mt-6">
              <button
                onClick={saveSettings}
                className="flex-1 py-2 rounded-lg bg-green-600 hover:bg-green-500 font-medium transition-colors"
              >
                💾 Сохранить
              </button>
              <button
                onClick={() => setShowSettingsModal(false)}
                className="flex-1 py-2 rounded-lg bg-gray-600 hover:bg-gray-500 font-medium transition-colors"
              >
                Отмена
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Specialist Modal */}
      {showSpecialistModal !== null && (() => {
        const currentMachine = machines.find(m => m.id === showSpecialistModal);
        if (!currentMachine) return null;
        return (
          <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
            <div className="bg-gray-800 rounded-xl border border-gray-600 p-6 w-full max-w-sm shadow-2xl">
              <h3 className="text-lg font-bold mb-1">Вызов специалистов</h3>
              <p className="text-gray-400 text-sm mb-1">
                {currentMachine.name} — {currentMachine.projectName}
              </p>
              <p className="text-xs text-gray-500 mb-4">
                Нажмите, чтобы вызвать/убрать. Можно выбрать нескольких.
              </p>
              <div className="grid grid-cols-1 gap-2">
                {SPECIALISTS.map(spec => {
                  const isActive = currentMachine.assignedSpecialists.includes(spec.type);
                  return (
                    <button
                      key={spec.type}
                      onClick={() => callSpecialist(showSpecialistModal, spec.type)}
                      className={`flex items-center gap-3 p-3 rounded-lg border transition-all ${
                        isActive
                          ? `${spec.color} border-white/30 shadow-lg`
                          : 'border-gray-600 hover:border-gray-400 hover:bg-gray-700'
                      }`}
                    >
                      <span className="text-2xl">{spec.icon}</span>
                      <span className="font-medium flex-1 text-left">{spec.label}</span>
                      {isActive && (
                        <span className="text-sm font-bold">✓ Вызван</span>
                      )}
                    </button>
                  );
                })}
              </div>
              {currentMachine.assignedSpecialists.length > 0 && (
                <div className="mt-3 p-2 bg-gray-700/50 rounded-lg">
                  <p className="text-xs text-gray-400">
                    Вызваны: {currentMachine.assignedSpecialists
                      .map(st => SPECIALISTS.find(s => s.type === st)?.label)
                      .filter(Boolean)
                      .join(', ')}
                  </p>
                </div>
              )}
              <div className="flex gap-2 mt-4">
                {currentMachine.assignedSpecialists.length > 0 && (
                  <button
                    onClick={() => {
                      clearAllSpecialists(showSpecialistModal);
                    }}
                    className="flex-1 py-2 rounded bg-red-600/80 hover:bg-red-500 text-sm font-medium transition-colors"
                  >
                    Отменить всех
                  </button>
                )}
                <button
                  onClick={() => setShowSpecialistModal(null)}
                  className="flex-1 py-2 rounded bg-gray-600 hover:bg-gray-500 text-sm font-medium transition-colors"
                >
                  Закрыть
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Notifications Settings Modal */}
      {showNotificationsModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-800 rounded-xl border border-gray-600 p-6 w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto">
            <h3 className="text-xl font-bold mb-1">🔔 Настройки уведомлений</h3>
            <p className="text-gray-400 text-sm mb-4">
              Настройте способы оповещения специалистов
            </p>

            {/* Telegram settings */}
            <div className="mb-4 p-3 bg-gray-700/50 rounded-lg border border-gray-600">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-bold text-blue-400">📱 Telegram Bot</h4>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={tempNotifSettings.telegramEnabled}
                    onChange={e =>
                      setTempNotifSettings(prev => ({
                        ...prev,
                        telegramEnabled: e.target.checked,
                      }))
                    }
                    className="w-4 h-4"
                  />
                  <span className="text-sm">Включить</span>
                </label>
              </div>
              <div className="space-y-2">
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Bot Token</label>
                  <input
                    type="text"
                    value={tempNotifSettings.telegramBotToken}
                    onChange={e =>
                      setTempNotifSettings(prev => ({
                        ...prev,
                        telegramBotToken: e.target.value,
                      }))
                    }
                    className="w-full bg-gray-700 border border-gray-600 rounded px-2 py-1.5 text-sm text-white font-mono"
                    placeholder="123456:ABC-DEF..."
                  />
                </div>

                {/* Пошаговая инструкция */}
                <div className="bg-blue-900/20 border border-blue-700 rounded-lg p-3 text-xs">
                  <p className="font-bold text-blue-300 mb-2">📖 Как создать бота (2 минуты):</p>
                  <ol className="space-y-1.5 text-blue-200">
                    <li className="flex gap-2">
                      <span className="font-bold text-blue-400">1.</span>
                      <span>
                        Откройте Telegram и перейдите к{' '}
                        <a
                          href="https://t.me/BotFather"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-400 underline font-medium hover:text-blue-300"
                        >
                          @BotFather
                        </a>
                      </span>
                    </li>
                    <li className="flex gap-2">
                      <span className="font-bold text-blue-400">2.</span>
                      <span>
                        Отправьте команду <code className="bg-blue-900/50 px-1 rounded">/newbot</code>
                      </span>
                    </li>
                    <li className="flex gap-2">
                      <span className="font-bold text-blue-400">3.</span>
                      <span>Введите имя бота (например: <i>ТПА Мониторинг</i>)</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="font-bold text-blue-400">4.</span>
                      <span>
                        Введите username (должен заканчиваться на <code className="bg-blue-900/50 px-1 rounded">bot</code>, например: <i>tpa_monitoring_bot</i>)
                      </span>
                    </li>
                    <li className="flex gap-2">
                      <span className="font-bold text-blue-400">5.</span>
                      <span>
                        BotFather пришлёт <b>токен</b> вида <code className="bg-blue-900/50 px-1 rounded">123456:ABC-DEF1234...</code> — скопируйте его в поле выше
                      </span>
                    </li>
                  </ol>
                  <a
                    href="https://t.me/BotFather"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-2 inline-block w-full text-center py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white font-medium transition-colors"
                  >
                    🚀 Открыть @BotFather в Telegram
                  </a>
                </div>

                <button
                  disabled={testing || !tempNotifSettings.telegramBotToken}
                  onClick={async () => {
                    setTesting(true);
                    setTestResult(null);
                    const firstContact = Object.values(tempNotifSettings.contacts).find(
                      c => c.telegramChatId
                    );
                    if (firstContact) {
                      const result = await testTelegramConnection(
                        tempNotifSettings.telegramBotToken,
                        firstContact.telegramChatId
                      );
                      setTestResult(result);
                    } else {
                      setTestResult({ ok: false, error: 'Укажите хотя бы один Chat ID' });
                    }
                    setTesting(false);
                  }}
                  className="w-full py-1.5 rounded bg-blue-600 hover:bg-blue-500 disabled:bg-gray-600 text-sm font-medium transition-colors"
                >
                  {testing ? '⏳ Проверка...' : '🧪 Тест подключения'}
                </button>
                {testResult && (
                  <div
                    className={`text-xs p-2 rounded ${
                      testResult.ok ? 'bg-green-900/30 text-green-400' : 'bg-red-900/30 text-red-400'
                    }`}
                  >
                    {testResult.ok ? '✅ Подключение работает!' : `❌ ${testResult.error}`}
                  </div>
                )}
              </div>
            </div>

            {/* Contacts per specialist */}
            <div className="mb-4">
              <h4 className="font-bold mb-2">👥 Chat ID специалистов</h4>
              <div className="text-xs text-gray-400 mb-2">
                Присвойте каждому специалисту его Telegram Chat ID для получения уведомлений
              </div>
              <div className="mb-3 p-2 bg-yellow-900/20 border border-yellow-700 rounded-lg text-xs text-yellow-300">
                ⚠️ <b>Важно:</b> каждый специалист должен один раз написать вашему боту{' '}
                <code className="bg-yellow-900/50 px-1 rounded">/start</code> в Telegram,
                иначе бот не сможет отправлять ему сообщения!
              </div>
              <div className="space-y-3">
                {SPECIALISTS.map(spec => {
                  const contact = tempNotifSettings.contacts[spec.type];
                  const hasChatId = contact.telegramChatId.trim().length > 0;
                  return (
                    <div
                      key={spec.type}
                      className={`p-3 rounded-lg border ${
                        hasChatId ? 'bg-green-900/10 border-green-700' : 'bg-gray-700/50 border-gray-600'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{spec.icon}</span>
                          <span className="font-medium text-sm">{spec.label}</span>
                          {hasChatId && (
                            <span className="text-xs bg-green-600/30 text-green-400 px-2 py-0.5 rounded-full">
                              ✓ ID задан
                            </span>
                          )}
                        </div>
                        <label className="flex items-center gap-1 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={contact.enabled}
                            onChange={e =>
                              setTempNotifSettings(prev => ({
                                ...prev,
                                contacts: {
                                  ...prev.contacts,
                                  [spec.type]: {
                                    ...prev.contacts[spec.type],
                                    enabled: e.target.checked,
                                  },
                                },
                              }))
                            }
                            className="w-3 h-3"
                          />
                          <span className="text-xs">Получает</span>
                        </label>
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs text-gray-400">Telegram Chat ID:</label>
                        <input
                          type="text"
                          value={contact.telegramChatId}
                          onChange={e =>
                            setTempNotifSettings(prev => ({
                              ...prev,
                              contacts: {
                                ...prev.contacts,
                                [spec.type]: {
                                  ...prev.contacts[spec.type],
                                  telegramChatId: e.target.value,
                                },
                              },
                            }))
                          }
                          className="w-full bg-gray-800 border border-gray-600 rounded px-2 py-1.5 text-sm text-white font-mono focus:outline-none focus:border-blue-500"
                          placeholder="Например: 123456789"
                        />
                        {hasChatId && tempNotifSettings.telegramEnabled && (
                          <button
                            onClick={async () => {
                              if (!tempNotifSettings.telegramBotToken) {
                                alert('Сначала укажите Bot Token');
                                return;
                              }
                              const result = await testTelegramConnection(
                                tempNotifSettings.telegramBotToken,
                                contact.telegramChatId
                              );
                              if (result.ok) {
                                alert(`✅ Тестовое сообщение отправлено ${spec.label}!`);
                              } else {
                                alert(`❌ Ошибка: ${result.error}`);
                              }
                            }}
                            className="w-full py-1 rounded bg-blue-600/50 hover:bg-blue-600 text-xs font-medium transition-colors"
                          >
                            🧪 Тест отправки {spec.label}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="mt-3 p-3 bg-blue-900/20 border border-blue-700 rounded-lg text-xs">
                <p className="font-bold text-blue-300 mb-2">💡 Как узнать Chat ID специалиста:</p>
                <ol className="space-y-1.5 text-blue-200">
                  <li className="flex gap-2">
                    <span className="font-bold text-blue-400">1.</span>
                    <span>
                      Специалист открывает в Telegram{' '}
                      <a
                        href="https://t.me/userinfobot"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-400 underline font-medium"
                      >
                        @userinfobot
                      </a>{' '}
                      и нажимает <b>Start</b>
                    </span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-bold text-blue-400">2.</span>
                    <span>Бот присылает ответ с его <b>Id</b> — это число (например: <code className="bg-blue-900/50 px-1 rounded">123456789</code>)</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-bold text-blue-400">3.</span>
                    <span>Специалист сообщает вам этот ID — вы вводите его в поле выше</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-bold text-blue-400">4.</span>
                    <span>
                      <b>Важно:</b> специалист должен сначала написать вашему боту <code className="bg-blue-900/50 px-1 rounded">/start</code>, иначе бот не сможет ему писать!
                    </span>
                  </li>
                </ol>
                <a
                  href="https://t.me/userinfobot"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-2 inline-block w-full text-center py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white font-medium transition-colors"
                >
                  🔍 Открыть @userinfobot в Telegram
                </a>
              </div>
            </div>

            {/* Other notification methods */}
            <div className="mb-4 space-y-2">
              <h4 className="font-bold mb-1">🔔 Другие способы</h4>
              <label className="flex items-center gap-2 cursor-pointer p-2 bg-gray-700/50 rounded-lg">
                <input
                  type="checkbox"
                  checked={tempNotifSettings.webNotificationsEnabled}
                  onChange={e =>
                    setTempNotifSettings(prev => ({
                      ...prev,
                      webNotificationsEnabled: e.target.checked,
                    }))
                  }
                  className="w-4 h-4"
                />
                <span className="text-sm">🖥️ Браузерные уведомления (Web Push)</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer p-2 bg-gray-700/50 rounded-lg">
                <input
                  type="checkbox"
                  checked={tempNotifSettings.soundEnabled}
                  onChange={e =>
                    setTempNotifSettings(prev => ({
                      ...prev,
                      soundEnabled: e.target.checked,
                    }))
                  }
                  className="w-4 h-4"
                />
                <span className="text-sm">🔊 Звуковое оповещение</span>
              </label>
            </div>

            <div className="flex gap-2">
              <button
                onClick={async () => {
                  if (tempNotifSettings.webNotificationsEnabled) {
                    await requestNotificationPermission();
                  }
                  setSettings(prev => ({
                    ...prev,
                    notifications: tempNotifSettings,
                  }));
                  setShowNotificationsModal(false);
                }}
                className="flex-1 py-2 rounded-lg bg-green-600 hover:bg-green-500 font-medium transition-colors"
              >
                💾 Сохранить
              </button>
              <button
                onClick={() => setShowNotificationsModal(false)}
                className="flex-1 py-2 rounded-lg bg-gray-600 hover:bg-gray-500 font-medium transition-colors"
              >
                Отмена
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Notification Logs Modal */}
      {showLogsModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-800 rounded-xl border border-gray-600 p-6 w-full max-w-2xl shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold">📋 Журнал уведомлений</h3>
              <button
                onClick={() => setNotificationLogs([])}
                className="px-3 py-1 rounded bg-red-600/80 hover:bg-red-500 text-xs font-medium transition-colors"
              >
                🗑️ Очистить
              </button>
            </div>
            {notificationLogs.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <p className="text-4xl mb-2">📭</p>
                <p>Уведомлений пока нет</p>
              </div>
            ) : (
              <div className="space-y-2">
                {notificationLogs.map(log => {
                  const spec = SPECIALISTS.find(s => s.type === log.specialist);
                  const time = new Date(log.timestamp).toLocaleTimeString('ru-RU');
                  const date = new Date(log.timestamp).toLocaleDateString('ru-RU');
                  return (
                    <div
                      key={log.id}
                      className={`p-3 rounded-lg border ${
                        log.status === 'sent'
                          ? 'bg-green-900/20 border-green-700'
                          : 'bg-red-900/20 border-red-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{spec?.icon}</span>
                          <span className="font-medium text-sm">{spec?.label}</span>
                          <span className="text-xs text-gray-400">→ {log.machineName}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span
                            className={`text-xs px-2 py-0.5 rounded-full ${
                              log.status === 'sent'
                                ? 'bg-green-600/30 text-green-400'
                                : 'bg-red-600/30 text-red-400'
                            }`}
                          >
                            {log.status === 'sent' ? '✅' : '❌'} {log.method}
                          </span>
                          <span className="text-xs text-gray-500">
                            {time} {date}
                          </span>
                        </div>
                      </div>
                      <p className="text-xs text-gray-400 whitespace-pre-line">{log.message}</p>
                    </div>
                  );
                })}
              </div>
            )}
            <button
              onClick={() => setShowLogsModal(false)}
              className="w-full mt-4 py-2 rounded-lg bg-gray-600 hover:bg-gray-500 font-medium transition-colors"
            >
              Закрыть
            </button>
          </div>
        </div>
      )}

      {/* Install Guide */}
      {showInstallGuide && <InstallGuide onClose={() => setShowInstallGuide(false)} />}

      {/* Footer */}
      <footer className={`${theme.header} border-t ${theme.border} py-3`}>
        <div className="max-w-[1920px] mx-auto px-4 text-center text-gray-500 text-xs">
          {settings.title} • Обновление: каждую секунду • Таймаут ошибки: 2 минуты
          {isLoggedIn && (
            <span className="ml-2 text-yellow-400">• Режим: Администратор</span>
          )}
        </div>
      </footer>
    </div>
  );
}

export default App;
