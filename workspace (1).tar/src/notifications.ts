import { SpecialistInfo, SpecialistType, NotificationSettings, NotificationLog } from './types';

export const SPECIALISTS_LIST: SpecialistInfo[] = [
  { type: 'electrician', label: 'Электрик', icon: '⚡', color: 'bg-yellow-500' },
  { type: 'mechanic', label: 'Механик', icon: '🔧', color: 'bg-blue-500' },
  { type: 'technologist', label: 'Технолог', icon: '🔬', color: 'bg-purple-500' },
  { type: 'operator', label: 'Оператор', icon: '👷', color: 'bg-green-500' },
  { type: 'maintenance', label: 'ТО', icon: '🛠️', color: 'bg-orange-500' },
];

export async function sendTelegramMessage(
  botToken: string,
  chatId: string,
  message: string
): Promise<boolean> {
  try {
    const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: 'HTML',
      }),
    });
    return response.ok;
  } catch (error) {
    console.error('Telegram send error:', error);
    return false;
  }
}

export async function testTelegramConnection(
  botToken: string,
  chatId: string
): Promise<{ ok: boolean; error?: string }> {
  try {
    const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: '✅ Тестовое сообщение от системы мониторинга ТПА. Подключение работает!',
      }),
    });
    if (response.ok) return { ok: true };
    const data = await response.json();
    return { ok: false, error: data.description || 'Неизвестная ошибка' };
  } catch (error) {
    return { ok: false, error: String(error) };
  }
}

export function sendWebNotification(title: string, body: string) {
  if ('Notification' in window && Notification.permission === 'granted') {
    const notification = new Notification(title, {
      body,
      icon: '🏭',
      badge: '🏭',
      tag: 'tpa-notification',
      requireInteraction: true,
    });
    notification.onclick = () => {
      window.focus();
      notification.close();
    };
    return true;
  }
  return false;
}

export async function requestNotificationPermission(): Promise<boolean> {
  if (!('Notification' in window)) return false;
  if (Notification.permission === 'granted') return true;
  if (Notification.permission === 'denied') return false;
  const permission = await Notification.requestPermission();
  return permission === 'granted';
}

export function playNotificationSound() {
  try {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.frequency.setValueAtTime(880, audioContext.currentTime);
    oscillator.frequency.setValueAtTime(660, audioContext.currentTime + 0.15);
    oscillator.frequency.setValueAtTime(880, audioContext.currentTime + 0.3);

    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);

    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.5);
  } catch (e) {
    console.error('Sound error:', e);
  }
}

export function buildCallMessage(
  machineName: string,
  projectName: string,
  specialist: SpecialistInfo
): string {
  const now = new Date();
  const time = now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
  const date = now.toLocaleDateString('ru-RU');

  return (
    `🚨 <b>ВЫЗОВ СПЕЦИАЛИСТА</b>\n\n` +
    `👤 Специалист: <b>${specialist.icon} ${specialist.label}</b>\n` +
    `🏭 Станок: <b>${machineName}</b>\n` +
    `📋 Проект: <b>${projectName}</b>\n` +
    `🕐 Время: ${time} (${date})\n\n` +
    `⚠️ Требуется ваше присутствие!`
  );
}

export function buildCancelMessage(
  machineName: string,
  specialist: SpecialistInfo
): string {
  const now = new Date();
  const time = now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });

  return (
    `✅ <b>ВЫЗОВ ОТМЕНЁН</b>\n\n` +
    `👤 ${specialist.icon} ${specialist.label}\n` +
    `🏭 Станок: <b>${machineName}</b>\n` +
    `🕐 ${time}\n\n` +
    `Работы завершены или вызов был ошибочным.`
  );
}

export async function notifySpecialist(
  settings: NotificationSettings,
  machineName: string,
  projectName: string,
  specialist: SpecialistInfo,
  action: 'call' | 'cancel'
): Promise<{ method: string; status: 'sent' | 'failed'; message: string }> {
  const message =
    action === 'call'
      ? buildCallMessage(machineName, projectName, specialist)
      : buildCancelMessage(machineName, specialist);

  const plainMessage = message.replace(/<[^>]+>/g, '');

  // Telegram
  if (settings.telegramEnabled && settings.telegramBotToken) {
    const contact = settings.contacts[specialist.type];
    if (contact.enabled && contact.telegramChatId) {
      const ok = await sendTelegramMessage(
        settings.telegramBotToken,
        contact.telegramChatId,
        message
      );
      if (ok) {
        return { method: 'Telegram', status: 'sent', message: plainMessage };
      }
      return { method: 'Telegram', status: 'failed', message: plainMessage };
    }
  }

  // Web Notifications fallback
  if (settings.webNotificationsEnabled) {
    const sent = sendWebNotification(
      action === 'call' ? `🚨 Вызов: ${specialist.label}` : `✅ Отмена: ${specialist.label}`,
      `${machineName} — ${projectName}`
    );
    if (sent) {
      return { method: 'Web Push', status: 'sent', message: plainMessage };
    }
  }

  // Sound fallback
  if (settings.soundEnabled) {
    playNotificationSound();
    return { method: 'Звук', status: 'sent', message: plainMessage };
  }

  return { method: 'Нет канала', status: 'failed', message: plainMessage };
}

export function getDefaultNotificationSettings(): NotificationSettings {
  return {
    telegramBotToken: '',
    telegramEnabled: false,
    webNotificationsEnabled: true,
    soundEnabled: true,
    contacts: {
      electrician: { telegramChatId: '', phone: '', enabled: true },
      mechanic: { telegramChatId: '', phone: '', enabled: true },
      technologist: { telegramChatId: '', phone: '', enabled: true },
      operator: { telegramChatId: '', phone: '', enabled: true },
      maintenance: { telegramChatId: '', phone: '', enabled: true },
    },
  };
}
