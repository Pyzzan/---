# 🚀 Шпаргалка по установке системы мониторинга ТПА

## Быстрый старт (5 минут)

```bash
# 1. Установите Node.js с https://nodejs.org

# 2. В папке проекта:
npm install
npm run build

# 3. Запустите:
npm run preview
# Откройте http://localhost:4173
```

---

## На сервер (Linux)

```bash
# Автоматическая установка:
sudo chmod +x install.sh
sudo ./install.sh

# Или вручную:
sudo apt update
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs nginx

sudo mkdir -p /var/www/tpa-monitor
# Скопируйте файлы в /var/www/tpa-monitor
cd /var/www/tpa-monitor
npm install && npm run build

# Настройте Nginx (см. nginx/tpa-monitor.conf)
# Откройте порты: sudo ufw allow 80/tcp
```

---

## Через Docker (1 команда)

```bash
# Установите Docker: curl -fsSL https://get.docker.com | sh
docker compose -f docker/docker-compose.yml up -d
```

---

## Удалённый доступ (3 варианта)

### ⚡ Cloudflare Tunnel (проще всего)
```bash
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o cloudflared
chmod +x cloudflared && sudo mv cloudflared /usr/local/bin/
cloudflared tunnel --url http://localhost:80
# Получите публичную ссылку!
```

### 🌐 VPS + домен
```bash
# 1. Арендуйте VPS (от 200₽/мес)
# 2. Купите домен (от 199₽/год)
# 3. Установите SSL:
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d tpa.ваш-домен.ru
```

### 🚀 Ngrok (для теста)
```bash
ngrok http 80
```

---

## Telegram-бот

1. Откройте [@BotFather](https://t.me/BotFather) → `/newbot` → получите токен
2. Специалисты: [@userinfobot](https://t.me/userinfobot) → Start → получите ID
3. В приложении: 🔔 Уведомления → вставьте токен и Chat ID

⚠️ Каждый специалист должен написать боту `/start` один раз!

---

## Вход админа

- **Логин:** admin
- **Пароль:** admin123
- ⚠️ Смените пароль после первого входа!

---

## Полезные ссылки

- Документация: [README.md](./README.md)
- Node.js: https://nodejs.org
- Docker: https://docker.com
- Cloudflare Tunnel: https://developers.cloudflare.com/cloudflare-one/connections/connect-apps/
- BotFather: https://t.me/BotFather
- User Info Bot: https://t.me/userinfobot
