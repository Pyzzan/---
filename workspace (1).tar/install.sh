#!/bin/bash
# Скрипт быстрой установки системы мониторинга ТПА
# Запуск: chmod +x install.sh && sudo ./install.sh

set -e

echo "🏭 Установка системы мониторинга ТПА"
echo "====================================="

# Проверка прав root
if [ "$EUID" -ne 0 ]; then
    echo "❌ Запустите скрипт с правами root: sudo ./install.sh"
    exit 1
fi

APP_DIR="/var/www/tpa-monitor"
DOMAIN=${1:-"localhost"}

echo ""
echo "📋 Параметры установки:"
echo "  - Папка: $APP_DIR"
echo "  - Домен: $DOMAIN"
echo ""

# 1. Обновление системы
echo "🔄 Обновление системы..."
apt update && apt upgrade -y

# 2. Установка Node.js
echo "📦 Установка Node.js 20 LTS..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt install -y nodejs
else
    echo "  ✓ Node.js уже установлен: $(node --version)"
fi

# 3. Установка Nginx
echo "🌐 Установка Nginx..."
if ! command -v nginx &> /dev/null; then
    apt install -y nginx
else
    echo "  ✓ Nginx уже установлен"
fi

# 4. Создание папки
echo "📁 Создание папки приложения..."
mkdir -p $APP_DIR

# 5. Копирование файлов (если есть в текущей директории)
if [ -f "package.json" ]; then
    echo "📂 Копирование файлов проекта..."
    cp -r . $APP_DIR/ 2>/dev/null || true
fi

cd $APP_DIR

# 6. Установка зависимостей
if [ -f "package.json" ]; then
    echo "📦 Установка npm зависимостей..."
    npm install
    echo "🔨 Сборка приложения..."
    npm run build
fi

# 7. Настройка Nginx
echo "⚙️  Настройка Nginx..."
cat > /etc/nginx/sites-available/tpa-monitor << EOF
server {
    listen 80;
    server_name $DOMAIN;

    root $APP_DIR/dist;
    index index.html;

    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml;

    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    location / {
        try_files \$uri \$uri/ /index.html;
    }
}
EOF

ln -sf /etc/nginx/sites-available/tpa-monitor /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

nginx -t
systemctl reload nginx

# 8. Firewall
echo "🔥 Настройка firewall..."
if command -v ufw &> /dev/null; then
    ufw allow 80/tcp
    ufw allow 443/tcp
    ufw allow 22/tcp
    echo "y" | ufw enable 2>/dev/null || true
fi

# 9. SSL (опционально)
if [ "$DOMAIN" != "localhost" ]; then
    echo ""
    read -p "🔒 Установить SSL сертификат (Let's Encrypt)? [y/N] " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        apt install -y certbot python3-certbot-nginx
        certbot --nginx -d $DOMAIN --non-interactive --agree-tos --email admin@$DOMAIN
    fi
fi

# 10. Права доступа
echo "🔐 Настройка прав доступа..."
chown -R www-data:www-data $APP_DIR
chmod -R 755 $APP_DIR

echo ""
echo "✅ Установка завершена!"
echo ""
echo "🌐 Приложение доступно по адресу:"
if [ "$DOMAIN" = "localhost" ]; then
    IP=$(hostname -I | awk '{print $1}')
    echo "   http://$IP"
    echo "   http://localhost"
else
    echo "   http://$DOMAIN"
fi
echo ""
echo "📝 Следующие шаги:"
echo "   1. Откройте адрес в браузере"
echo "   2. Войдите как администратор (admin / admin123)"
echo "   3. Смените пароль в настройках"
echo "   4. Настройте Telegram-бот для уведомлений"
echo ""
echo "📖 Полная документация: $APP_DIR/README.md"
