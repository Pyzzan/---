@echo off
REM Скрипт быстрой установки системы мониторинга ТПА для Windows
REM Запуск: запустите install.bat от имени администратора

echo.
echo ==========================================
echo  Установка системы мониторинга ТПА
echo ==========================================
echo.

REM Проверка прав администратора
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Запустите скрипт от имени администратора!
    pause
    exit /b 1
)

REM Проверка Node.js
where node >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Node.js не установлен.
    echo [!] Скачайте и установите с https://nodejs.org/
    echo [!] После установки перезапустите этот скрипт.
    start https://nodejs.org/
    pause
    exit /b 1
)

echo [OK] Node.js найден:
node --version
echo.

REM Установка зависимостей
echo [*] Установка npm зависимостей...
call npm install
if %errorLevel% neq 0 (
    echo [!] Ошибка установки зависимостей
    pause
    exit /b 1
)
echo.

REM Сборка
echo [*] Сборка приложения...
call npm run build
if %errorLevel% neq 0 (
    echo [!] Ошибка сборки
    pause
    exit /b 1
)
echo.

echo [OK] Приложение собрано в папке dist\
echo.

REM Запуск preview-сервера
echo [*] Запуск сервера...
echo.
echo ==========================================
echo  Приложение запущено!
echo  Откройте: http://localhost:4173
echo  Для остановки: Ctrl+C
echo ==========================================
echo.

call npm run preview

pause
