# 🏭 Система мониторинга ТПА — Инструкция по установке и развёртыванию

## 📋 Содержание

1. [Быстрый старт (локально)](#1-быстрый-старт-локально)
2. [Установка на внутренний сервер](#2-установка-на-внутренний-сервер)
3. [Удалённый доступ через интернет](#3-удалённый-доступ-через-интернет)
4. [Docker-развёртывание](#4-docker-развёртывание)
5. [Настройка Telegram-бота](#5-настройка-telegram-бота)
6. [Безопасность](#6-безопасность)
7. [Решение проблем](#7-решение-проблем)

---

## 1. Быстрый старт (локально)

### Требования:
- Node.js 18+ ([скачать](https://nodejs.org/))
- npm (идёт вместе с Node.js)

### Установка:

```bash
# 1. Клонируйте или скопируйте проект в папку
cd /path/to/project

# 2. Установите зависимости
npm install

# 3. Запустите в режиме разработки
npm run dev

# 4. Откройте в браузере
# http://localhost:5173
```

### Сборка для продакшена:

```bash
# Собрать оптимизированную версию
npm run build

# Файлы будут в папке dist/
# Их можно отдать любому веб-серверу
```

---

## 2. Установка на внутренний сервер

### Вариант А: Linux (Ubuntu/Debian) — рекомендуемый

#### Шаг 1: Установка Node.js

```bash
# Обновление системы
sudo apt update && sudo apt upgrade -y

# Установка Node.js 20 LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Проверка
node --version   # Должно быть v20.x.x
npm --version    # Должно быть 10.x.x
```

#### Шаг 2: Установка проекта

```bash
# Создаём папку для приложения
sudo mkdir -p /var/www/tpa-monitor
sudo chown $USER:$USER /var/www/tpa-monitor
cd /var/www/tpa-monitor

# Копируем файлы проекта (или git clone)
# ...

# Устанавливаем зависимости и собираем
npm install
npm run build
```

#### Шаг 3: Установка Nginx

```bash
sudo apt install -y nginx
```

#### Шаг 4: Конфигурация Nginx

Создайте файл `/etc/nginx/sites-available/tpa-monitor`:

```bash
sudo nano /etc/nginx/sites-available/tpa-monitor
```

Вставьте содержимое из файла `nginx/tpa-monitor.conf` (см. папку `nginx/` в проекте).

Активируйте сайт:

```bash
sudo ln -s /etc/nginx/sites-available/tpa-monitor /etc/nginx/sites-enabled/
sudo nginx -t          # Проверка конфига
sudo systemctl reload nginx
```

#### Шаг 5: Автозапуск через systemd

Создайте сервис `/etc/systemd/system/tpa-monitor.service`:

```bash
sudo nano /etc/systemd/system/tpa-monitor.service
```

Содержимое — см. файл `systemd/tpa-monitor.service` в проекте.

```bash
sudo systemctl daemon-reload
sudo systemctl enable tpa-monitor
sudo systemctl start tpa-monitor
sudo systemctl status tpa-monitor
```

#### Шаг 6: Открытие портов в firewall

```bash
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

Теперь приложение доступно по адресу `http://IP-СЕРВЕРА` в локальной сети.

---

### Вариант Б: Windows Server

1. Установите [Node.js](https://nodejs.org/) (LTS версия)
2. Установите [Nginx для Windows](http://nginx.org/en/download.html)
3. Распакуйте Nginx в `C:\nginx`
4. Скопируйте проект в `C:\tpa-monitor`
5. Выполните `npm install && npm run build`
6. Скопируйте `nginx/nginx-windows.conf` в `C:\nginx\conf\nginx.conf`
7. Запустите: `cd C:\nginx && start nginx.exe`

Для автозапуска используйте NSSM:

```powershell
# Скачать NSSM: https://nssm.cc/download
nssm install TPA_MONITOR "C:\Program Files\nodejs\node.exe" "C:\tpa-monitor\server.js"
nssm start TPA_MONITOR
```

---

## 3. Удалённый доступ через интернет

### ⚡ Вариант 1: Cloudflare Tunnel (РЕКОМЕНДУЕТСЯ) — бесплатно и безопасно

Самый простой способ — не нужно открывать порты, настраивать домен или SSL.

```bash
# 1. Установите cloudflared
# Linux:
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o cloudflared
chmod +x cloudflared
sudo mv cloudflared /usr/local/bin/

# Windows: скачать с https://github.com/cloudflare/cloudflared/releases

# 2. Авторизация
cloudflared tunnel login

# 3. Создание туннеля
cloudflared tunnel create tpa-monitor

# 4. Запуск
cloudflared tunnel --url http://localhost:80
```

Вы получите публичную ссылку вида `https://xxx-xxx-xxx.trycloudflare.com` — её можно давать сотрудникам.

#### Постоянный туннель с доменом:

1. Купите домен (например, на [reg.ru](https://reg.ru) или [namecheap.com](https://namecheap.com))
2. Подключите его к Cloudflare (бесплатный план)
3. Создайте DNS-запись CNAME: `tpa.ваш-домен.ru` → ID туннеля
4. Настройте туннель:

```yaml
# ~/.cloudflared/config.yml
tunnel: <ID-ТУННЕЛЯ>
credentials-file: /root/.cloudflared/<ID-ТУННЕЛЯ>.json

ingress:
  - hostname: tpa.ваш-домен.ru
    service: http://localhost:80
  - service: http_status:404
```

```bash
# Запуск как сервис
sudo cloudflared service install
sudo systemctl start cloudflared
```

---

### 🌐 Вариант 2: VPS + Nginx + HTTPS (классический способ)

#### Шаг 1: Аренда VPS

Рекомендуемые провайдеры (от 200₽/мес):
- [Timeweb Cloud](https://timeweb.cloud)
- [Beget](https://beget.com)
- [Selectel](https://selectel.ru)
- [Hetzner](https://hetzner.com) (европейский)

Минимальные требования: 1 vCPU, 1 GB RAM, 10 GB SSD, Ubuntu 22.04.

#### Шаг 2: Покупка домена

- [reg.ru](https://reg.ru) — от 199₽/год
- [namecheap.com](https://namecheap.com) — от $8/год

Настройте DNS-запись A: `tpa.ваш-домен.ru` → IP вашего VPS.

#### Шаг 3: Установка SSL (Let's Encrypt)

```bash
sudo apt install -y certbot python3-certbot-nginx

# Получение сертификата
sudo certbot --nginx -d tpa.ваш-домен.ru

# Автопродление (уже настроено автоматически)
sudo certbot renew --dry-run
```

#### Шаг 4: Настройка Nginx для HTTPS

После certbot конфиг Nginx обновится автоматически. Проверьте:

```bash
sudo nginx -t
sudo systemctl reload nginx
```

Теперь сайт доступен по `https://tpa.ваш-домен.ru`.

---

### 🚀 Вариант 3: Ngrok (быстрый тест, бесплатно)

Для временного доступа или демонстрации:

```bash
# Установка
curl -s https://ngrok-agent.s3.amazonaws.com/ngrok.asc | sudo tee /etc/apt/trusted.gpg.d/ngrok.asc
echo "deb https://ngrok-agent.s3.amazonaws.com buster main" | sudo tee /etc/apt/sources.list.d/ngrok.list
sudo apt update && sudo apt install ngrok

# Авторизация (получите токен на https://dashboard.ngrok.com)
ngrok config add-authtoken ВАШ_ТОКЕН

# Запуск
ngrok http 80
```

Получите ссылку вида `https://xxxx.ngrok-free.app`.

⚠️ **Минусы:** ссылка меняется при каждом перезапуске (в бесплатной версии), медленно.

---

### 🏠 Вариант 4: Проброс портов через роутер (белый IP)

Если у вас есть **белый (публичный) IP** на предприятии:

1. Зайдите в настройки роутера (обычно 192.168.1.1)
2. Найдите раздел «Переадресация портов» / «Port Forwarding»
3. Создайте правило:
   - Внешний порт: 80 (или 8080)
   - Внутренний IP: IP вашего сервера
   - Внутренний порт: 80
   - Протокол: TCP
4. Для HTTPS добавьте порт 443
5. Используйте DDNS-сервис (например, [No-IP](https://noip.com)), если IP динамический

⚠️ **Внимание:** этот способ открывает ваш сервер напрямую в интернет — обязательно настройте firewall и HTTPS!

---

## 4. Docker-развёртывание

Самый простой способ для продакшена — через Docker.

### Установка Docker:

```bash
# Ubuntu/Debian
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
# Перелогиньтесь

# Проверка
docker --version
docker compose version
```

### Запуск приложения:

```bash
# Клонируйте проект
cd /var/www/tpa-monitor

# Запустите
docker compose up -d

# Приложение доступно на http://localhost:80
```

### Полезные команды:

```bash
# Логи
docker compose logs -f

# Перезапуск
docker compose restart

# Остановка
docker compose down

# Обновление
docker compose pull
docker compose up -d
```

---

## 5. Настройка Telegram-бота

### Создание бота:

1. Откройте [@BotFather](https://t.me/BotFather) в Telegram
2. Отправьте `/newbot`
3. Введите имя (например: `ТПА Мониторинг Цех`)
4. Введите username (обязательно заканчивается на `bot`, например: `tpa_cesh_bot`)
5. Скопируйте токен вида `123456789:ABCdefGHI...`
6. Вставьте токен в приложении: **🔔 Уведомления** → **Bot Token**

### Получение Chat ID специалистов:

1. Каждый специалист открывает [@userinfobot](https://t.me/userinfobot)
2. Нажимает **Start**
3. Копирует свой **Id** (число, например `123456789`)
4. Сообщает ID администратору
5. Администратор вводит ID в приложении для соответствующего специалиста

### ⚠️ Важно:

Каждый специалист должен **один раз** написать вашему боту `/start` в Telegram, иначе бот не сможет ему писать (политика Telegram).

### Проверка работы:

```bash
# Тест из командной строки (замените значения)
curl -X POST https://api.telegram.org/bot<ВАШ_ТОКЕН>/sendMessage \
  -H "Content-Type: application/json" \
  -d '{"chat_id":"<CHAT_ID>","text":"Тестовое сообщение"}'
```

Если сообщение пришло — всё работает!

---

## 6. Безопасность

### Обязательные меры:

1. **Смените пароль админа** в настройках приложения
2. **Используйте HTTPS** — никогда не передавайте данные по HTTP
3. **Ограничьте доступ по IP** (если возможно):

```nginx
# В конфиге Nginx
location / {
    allow 192.168.1.0/24;    # Локальная сеть
    allow 10.0.0.0/8;        # VPN
    deny all;
}
```

4. **Регулярно обновляйте** систему:

```bash
sudo apt update && sudo apt upgrade -y
```

5. **Резервное копирование** настроек:

```bash
# Скрипт бэкапа
#!/bin/bash
BACKUP_DIR="/backup/tpa-monitor"
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p $BACKUP_DIR
tar -czf $BACKUP_DIR/tpa-monitor-$DATE.tar.gz /var/www/tpa-monitor
```

### Рекомендации:

- Используйте Cloudflare Tunnel — скрывает реальный IP сервера
- Включите двухфакторную аутентификацию на VPS
- Настройте fail2ban для защиты от брутфорса
- Храните токен Telegram-бота в секрете

---

## 7. Решение проблем

### Бот Telegram не отправляет сообщения

```bash
# Проверка токена
curl https://api.telegram.org/bot<ТОКЕН>/getMe

# Должен вернуть информацию о боте
```

**Частые причины:**
- Специалист не написал боту `/start`
- Неверный Chat ID
- Бот заблокирован (удалён) — создайте нового

### Nginx выдаёт 502 Bad Gateway

```bash
# Проверьте, запущено ли приложение
sudo systemctl status tpa-monitor

# Перезапустите
sudo systemctl restart tpa-monitor

# Посмотрите логи
journalctl -u tpa-monitor -n 50
```

### Не работает удалённый доступ

1. Проверьте, что сервер доступен локально: `curl http://localhost`
2. Проверьте firewall: `sudo ufw status`
3. Проверьте, что порт открыт: `sudo netstat -tlnp | grep :80`
4. Для Cloudflare Tunnel: `cloudflared tunnel info tpa-monitor`

### Приложение не запускается после обновления

```bash
cd /var/www/tpa-monitor
rm -rf node_modules dist
npm install
npm run build
sudo systemctl restart tpa-monitor
```

---

## 📞 Поддержка

При возникновении проблем:
1. Проверьте логи: `journalctl -u tpa-monitor -f`
2. Проверьте логи Nginx: `sudo tail -f /var/log/nginx/error.log`
3. Проверьте доступность Telegram API: `curl https://api.telegram.org`

---

## 📁 Структура файлов для развёртывания

```
tpa-monitor/
├── dist/                    # Собранные файлы (после npm run build)
├── nginx/
│   ├── tpa-monitor.conf     # Конфиг Nginx для Linux
│   └── nginx-windows.conf   # Конфиг Nginx для Windows
├── systemd/
│   └── tpa-monitor.service  # Systemd unit для автозапуска
├── docker/
│   ├── Dockerfile           # Dockerfile для контейнера
│   └── docker-compose.yml   # Docker Compose
├── package.json
└── README.md                # Этот файл
```

---

**Версия документации:** 1.0  
**Дата:** 2026
